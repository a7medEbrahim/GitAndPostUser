part of 'user_cubit.dart';

@immutable
abstract class UserState {}

class UserInitial extends UserState {}

class GetUsersLoading extends UserState {}

class GetUsersSuccess extends UserState {
  UserModel user;
  GetUsersSuccess(this.user);
}

class GetUsersError extends UserState {
  final String error;
  GetUsersError(this.error);
}