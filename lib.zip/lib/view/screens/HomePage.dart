import 'package:flutter/material.dart';
import 'package:task1/Cupits/user_cubit.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../models/UserModel.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static const String routeName = "homePage";

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => UserCubit()..getUser(),
      child: BlocConsumer<UserCubit, UserState>(
        listener: (context, state) {
          // TODO: implement listener
        },
        builder: (context, state) {
          if( state is GetUsersLoading){
            return Center(child: CircularProgressIndicator());
          }
          else if(state is GetUsersSuccess){
            print(state);
            return Scaffold(
                appBar: AppBar(
                  title: Text(state.user.users?[0].firstName??""),
                ),
                body: Center(
                  child: Text('Screen One'),
                )
            );
          }else{
            return SizedBox(height: 10,);
          }
        },
      ),
    );
  }
}
